# main.py
# UMA / Nugget One-Bit Monte Carlo Timing Engine
# Target: Waveshare RP2040-Zero or compatible RP2040-Zero clone
# Board features used:
#   - RP2040 PIO
#   - USB serial / Web Serial command protocol
#   - onboard WS2812 / NeoPixel on GP16
#   - onboard USER button, assumed GP14 until bench-verified
#
# Version: 0.3
#
# v0.3 fixes from firmware review:
#   1. Removes blocking 20 ms LED flash from the sampling loop.
#   2. Replaces blocking readline() with a nonblocking character line buffer.
#   3. Makes PIO sampler modes mutually exclusive: direct sampler or latch sampler.
#   4. Documents that Python overhead remains outside the requested random dwell.
#   5. Stops / tri-states PWM when switching to external-source modes.
#   6. Adds MAX_TRIALS cap and warning event.
#
# Safety:
#   RP2040 GPIO is 3.3 V only. Do not connect 5 V 555/7400 outputs directly
#   to RP2040 GPIO. Use 3.3 V logic, divider, buffer, or level shifter.

import sys
import time
import random
import math

try:
    import select
except ImportError:
    select = None

from machine import Pin, PWM
import rp2


# -----------------------------
# Board pin map: verify on bench
# -----------------------------

NEOPIXEL_PIN       = 16    # documented for Waveshare RP2040-Zero WS2812
USER_BUTTON_PIN    = 14    # likely for pictured clone; verify with BUTTON?

PWM_OUT_PIN        = 0     # internal known-duty waveform output
SAMPLE_IN_PIN      = 4     # one-bit input; jumper GP0 -> GP4 for internal mode

LATCH_RESET_PIN    = 2     # external latch reset output
LATCH_SAMPLE_PIN   = 3     # external latch/capture output; must follow reset pin
LATCH_Q_PIN        = 4     # external latch Q input; aliases SAMPLE_IN_PIN

DEBUG_PIN          = 5     # scope / logic analyzer gate pulse

USER_BUTTON_ACTIVE_LOW = True

MAX_TRIALS = 100_000
DEFAULT_SAMPLE_LED_HOLD_MS = 0  # 0 = no blocking LED hold during RUN


# -----------------------------
# WS2812 / NeoPixel status LED
# -----------------------------

@rp2.asm_pio(
    sideset_init=rp2.PIO.OUT_LOW,
    out_shiftdir=rp2.PIO.SHIFT_LEFT,
    autopull=True,
    pull_thresh=24,
)
def _ws2812():
    T1 = 2
    T2 = 5
    T3 = 3
    wrap_target()
    label("bitloop")
    out(x, 1)               .side(0) [T3 - 1]
    jmp(not_x, "do_zero")   .side(1) [T1 - 1]
    jmp("bitloop")          .side(1) [T2 - 1]
    label("do_zero")
    nop()                   .side(0) [T2 - 1]
    wrap()


class StatusLED:
    COLORS = {
        "off":      (0, 0, 0),
        "boot":     (80, 80, 80),
        "ready":    (0, 0, 120),
        "armed":    (0, 80, 120),
        "running":  (100, 0, 140),
        "high":     (0, 160, 0),
        "low":      (180, 100, 0),
        "done":     (0, 160, 160),
        "error":    (180, 0, 0),
        "button":   (255, 255, 255),
    }

    def __init__(self, pin=NEOPIXEL_PIN, sm_id=0, brightness=0.08):
        self.pin = pin
        self.brightness = brightness
        self.ok = False
        self.current = "off"
        try:
            self.sm = rp2.StateMachine(
                sm_id, _ws2812, freq=8_000_000, sideset_base=Pin(pin)
            )
            self.sm.active(1)
            self.ok = True
            self.set("off")
        except Exception as e:
            self.ok = False
            print("WARN,neopixel_init_failed,%s" % repr(e))

    def rgb(self, r, g, b):
        if not self.ok:
            return
        r = int(max(0, min(255, r)) * self.brightness)
        g = int(max(0, min(255, g)) * self.brightness)
        b = int(max(0, min(255, b)) * self.brightness)
        grb = (g << 16) | (r << 8) | b
        self.sm.put(grb << 8)

    def set(self, name):
        self.current = name
        self.rgb(*self.COLORS.get(name, (40, 40, 40)))

    def flash_blocking(self, name, ms=40, then="ready"):
        # Use only outside timing-critical RUN loops.
        self.set(name)
        time.sleep_ms(ms)
        self.set(then)


# ------------------------------------------
# PIO one-bit direct sampler and latch engine
# ------------------------------------------

@rp2.asm_pio(in_shiftdir=rp2.PIO.SHIFT_LEFT)
def _pio_direct_sample():
    # Python writes one token; PIO samples one input pin and pushes one bit.
    wrap_target()
    pull(block)
    mov(isr, null)
    in_(pins, 1)
    push(block)
    wrap()


@rp2.asm_pio(
    set_init=(rp2.PIO.OUT_LOW, rp2.PIO.OUT_LOW),
    in_shiftdir=rp2.PIO.SHIFT_LEFT,
)
def _pio_latch_transaction():
    # set_base controls two consecutive pins:
    #   bit0 = reset
    #   bit1 = sample/capture
    # in_base reads latch Q.
    #
    # With freq=1 MHz, each delay cycle is approximately 1 us.
    wrap_target()
    pull(block)

    set(pins, 0b01) [4]     # reset high
    set(pins, 0b00) [4]     # reset low

    nop() [8]               # settle

    set(pins, 0b10) [4]     # sample high
    set(pins, 0b00) [4]     # sample low

    nop() [8]               # latch output settle

    mov(isr, null)
    in_(pins, 1)
    push(block)
    wrap()


class PIOSampler:
    def __init__(self):
        self.direct_sm = None
        self.latch_sm = None
        self.active_mode = None
        self.debug = Pin(DEBUG_PIN, Pin.OUT, value=0)

    def init_direct(self, sample_pin=SAMPLE_IN_PIN):
        if self.direct_sm is None:
            self.direct_sm = rp2.StateMachine(
                1,
                _pio_direct_sample,
                freq=2_000_000,
                in_base=Pin(sample_pin, Pin.IN, Pin.PULL_DOWN),
            )

    def init_latch(self, q_pin=LATCH_Q_PIN, reset_pin=LATCH_RESET_PIN):
        if LATCH_SAMPLE_PIN != reset_pin + 1:
            raise ValueError("LATCH_SAMPLE_PIN must equal LATCH_RESET_PIN + 1")
        if self.latch_sm is None:
            self.latch_sm = rp2.StateMachine(
                2,
                _pio_latch_transaction,
                freq=1_000_000,
                set_base=Pin(reset_pin),
                in_base=Pin(q_pin, Pin.IN, Pin.PULL_DOWN),
            )

    def select_direct(self):
        self.init_direct()
        if self.latch_sm is not None:
            self.latch_sm.active(0)
        self.direct_sm.active(1)
        self.active_mode = "direct"

    def select_latch(self):
        self.init_latch()
        if self.direct_sm is not None:
            self.direct_sm.active(0)
        self.latch_sm.active(1)
        self.active_mode = "latch"

    def direct_sample(self):
        if self.active_mode != "direct":
            self.select_direct()
        self.debug.value(1)
        self.direct_sm.put(1)
        raw = self.direct_sm.get()
        self.debug.value(0)
        return raw & 1

    def latch_transaction(self):
        if self.active_mode != "latch":
            self.select_latch()
        self.debug.value(1)
        self.latch_sm.put(1)
        raw = self.latch_sm.get()
        self.debug.value(0)
        return raw & 1


# -----------------------------
# Main workbench application
# -----------------------------

class Workbench:
    MODES = (
        "PIO_DIRECT_INTERNAL_PWM",
        "PIO_DIRECT_EXTERNAL",
        "PIO_LATCH_EXTERNAL",
        "BUTTON_DIRECT_INTERNAL_PWM",
        "BUTTON_DIRECT_EXTERNAL",
    )

    INTERNAL_PWM_MODES = (
        "PIO_DIRECT_INTERNAL_PWM",
        "BUTTON_DIRECT_INTERNAL_PWM",
    )

    BUTTON_MODES = (
        "BUTTON_DIRECT_INTERNAL_PWM",
        "BUTTON_DIRECT_EXTERNAL",
    )

    def __init__(self):
        self.led = StatusLED()
        self.led.set("boot")

        self.sampler = PIOSampler()
        self.button = Pin(USER_BUTTON_PIN, Pin.IN, Pin.PULL_UP)

        self.pwm = None
        self.mode = "PIO_DIRECT_INTERNAL_PWM"

        self.trials_target = 1000
        self.report_every = 25
        self.freq_hz = 1000
        self.duty_percent = 37.0
        self.random_min_us = 700
        self.random_max_us = 9700
        self.expected = None

        self.sample_led_hold_ms = DEFAULT_SAMPLE_LED_HOLD_MS
        self.running = False

        self.rx_buffer = ""
        self.poller = None
        self._init_serial_poller()

        self.reset_counts()
        self.apply_mode_resources()
        self.print_hello()
        self.print_csv_header()

        self.led.set("ready")

    def _init_serial_poller(self):
        if select is None:
            return
        try:
            self.poller = select.poll()
            self.poller.register(sys.stdin, select.POLLIN)
        except Exception as e:
            self.poller = None
            print("WARN,serial_poller_unavailable,%s" % repr(e))

    def reset_counts(self):
        self.trial = 0
        self.high = 0
        self.low = 0
        self.last_bit = -1

    def is_internal_pwm_mode(self):
        return self.mode in self.INTERNAL_PWM_MODES

    def is_button_mode(self):
        return self.mode in self.BUTTON_MODES

    def configure_pwm(self):
        if self.pwm is not None:
            try:
                self.pwm.deinit()
            except Exception:
                pass
        pin = Pin(PWM_OUT_PIN, Pin.OUT)
        self.pwm = PWM(pin)
        duty = int(max(0, min(65535, round(65535 * self.duty_percent / 100.0))))
        self.pwm.freq(int(self.freq_hz))
        self.pwm.duty_u16(duty)

    def stop_pwm(self):
        if self.pwm is not None:
            try:
                self.pwm.deinit()
            except Exception:
                pass
            self.pwm = None
        # Tri-state GP0 so external-source modes are not confused by a still-driven output.
        try:
            Pin(PWM_OUT_PIN, Pin.IN, Pin.PULL_DOWN)
        except Exception:
            pass

    def apply_mode_resources(self):
        if self.is_internal_pwm_mode():
            self.configure_pwm()
        else:
            self.stop_pwm()

        if self.mode == "PIO_LATCH_EXTERNAL":
            self.sampler.select_latch()
        else:
            self.sampler.select_direct()

    def button_pressed(self):
        v = self.button.value()
        return (v == 0) if USER_BUTTON_ACTIVE_LOW else (v == 1)

    def wait_button_release(self):
        t0 = time.ticks_ms()
        while self.button_pressed() and time.ticks_diff(time.ticks_ms(), t0) < 1500:
            time.sleep_ms(5)

    def expected_fraction(self):
        if self.expected is not None:
            return self.expected
        if self.is_internal_pwm_mode():
            return self.duty_percent / 100.0
        return -1.0

    def standard_error(self, p_hat=None, n=None):
        if n is None:
            n = self.trial
        if n <= 0:
            return 0.0
        if p_hat is None:
            p_hat = self.high / n
        return math.sqrt(max(0.0, p_hat * (1.0 - p_hat) / n))

    def update_sample_led(self, bit):
        # Timing-critical policy:
        # During RUN, do not block for LED animation. Set color only.
        # If sample_led_hold_ms is deliberately set > 0, keep it tiny.
        self.led.set("high" if bit else "low")
        if self.sample_led_hold_ms > 0:
            time.sleep_ms(self.sample_led_hold_ms)
            self.led.set("running" if self.running else "ready")

    def record_bit(self, bit, report=True):
        self.trial += 1
        self.last_bit = bit
        if bit:
            self.high += 1
        else:
            self.low += 1

        self.update_sample_led(bit)

        if report:
            if self.trial == 1 or self.trial % self.report_every == 0 or self.trial >= self.trials_target:
                self.print_data()

    def sample_once(self):
        if self.mode == "PIO_LATCH_EXTERNAL":
            return self.sampler.latch_transaction()
        return self.sampler.direct_sample()

    def auto_step(self):
        # Methodological note:
        # This sleep defines the requested random dwell before the next sample.
        # Python overhead, serial reporting, and LED updating occur outside that dwell.
        # v0.3 removes the major 20 ms LED distortion from v0.2.
        delay_us = random.randint(self.random_min_us, self.random_max_us)
        time.sleep_us(delay_us)
        bit = self.sample_once()
        self.record_bit(bit, report=True)

    def run(self):
        self.running = True
        self.led.set("running")
        print("EVENT,run_started,mode=%s,trials=%d" % (self.mode, self.trials_target))

        while self.running and self.trial < self.trials_target:
            self.poll_serial_once()

            if self.is_button_mode():
                if self.button_pressed():
                    # Human-triggered mode is intentionally not a strict random sampler.
                    self.led.set("button")
                    time.sleep_ms(20)  # debounce, acceptable only in button mode
                    if self.button_pressed():
                        bit = self.sample_once()
                        self.record_bit(bit, report=True)
                        self.wait_button_release()
                else:
                    time.sleep_ms(3)
            else:
                self.auto_step()

        self.running = False
        self.led.set("done")
        print("EVENT,run_complete,trial=%d,high=%d,low=%d" % (self.trial, self.high, self.low))
        self.print_data()

    def stop(self):
        self.running = False
        self.led.set("ready")
        print("EVENT,stopped")

    def print_hello(self):
        print("HELLO,UMA_RP2040_ZERO_ONE_BIT_ENGINE,version=0.3")
        print("BOARD,pwm_out=GP%d,sample_in=GP%d,latch_reset=GP%d,latch_sample=GP%d,latch_q=GP%d,neopixel=GP%d,user_button=GP%d,debug=GP%d" %
              (PWM_OUT_PIN, SAMPLE_IN_PIN, LATCH_RESET_PIN, LATCH_SAMPLE_PIN,
               LATCH_Q_PIN, NEOPIXEL_PIN, USER_BUTTON_PIN, DEBUG_PIN))

    def print_csv_header(self):
        print("CSV,trial,high,low,estimate,expected,error,se,ci95_low,ci95_high,mode,last_bit")

    def print_data(self):
        n = self.trial
        if n <= 0:
            estimate = 0.0
            se = 0.0
            lo = 0.0
            hi = 0.0
        else:
            estimate = self.high / n
            se = self.standard_error(estimate, n)
            lo = max(0.0, estimate - 1.96 * se)
            hi = min(1.0, estimate + 1.96 * se)

        exp = self.expected_fraction()
        err = estimate - exp if exp >= 0 else 0.0

        print("DATA,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%s,%d" %
              (n, self.high, self.low, estimate, exp, err, se, lo, hi, self.mode, self.last_bit))

    def print_status(self):
        print("STATUS,mode=%s,running=%d,trial=%d,high=%d,low=%d,freq=%d,duty=%.3f,report_every=%d,random_us=%d:%d,expected=%s,button=%d,pwm_active=%d,sample_led_hold_ms=%d,max_trials=%d" %
              (self.mode, 1 if self.running else 0, self.trial, self.high, self.low,
               self.freq_hz, self.duty_percent, self.report_every,
               self.random_min_us, self.random_max_us,
               "AUTO" if self.expected is None else ("%.6f" % self.expected),
               1 if self.button_pressed() else 0,
               1 if self.pwm is not None else 0,
               self.sample_led_hold_ms,
               MAX_TRIALS))

    def set_mode(self, mode):
        mode = mode.upper()
        if mode not in self.MODES:
            raise ValueError("unknown mode")
        old_mode = self.mode
        self.mode = mode
        self.apply_mode_resources()
        print("EVENT,mode_set,old=%s,new=%s,pwm_active=%d" %
              (old_mode, self.mode, 1 if self.pwm is not None else 0))

    def set_trials(self, requested):
        requested = int(requested)
        if requested < 1:
            requested = 1
        if requested > MAX_TRIALS:
            print("EVENT,warn_large_trials,requested=%d,clamped=%d" % (requested, MAX_TRIALS))
            requested = MAX_TRIALS
        self.trials_target = requested
        print("EVENT,trials_set,%d" % self.trials_target)

    def parse_command(self, line):
        line = line.strip()
        if not line:
            return

        print("CMD,%s" % line)
        parts = line.split()
        cmd = parts[0].upper()

        try:
            if cmd == "HELLO":
                self.print_hello()

            elif cmd == "STATUS" or cmd == "CONFIG?":
                self.print_status()

            elif cmd == "CSV?":
                self.print_csv_header()

            elif cmd == "BUTTON?":
                print("BUTTON,pin=GP%d,pressed=%d,raw=%d" %
                      (USER_BUTTON_PIN, 1 if self.button_pressed() else 0, self.button.value()))

            elif cmd == "RESET":
                self.reset_counts()
                self.led.set("ready")
                print("EVENT,counts_reset")
                self.print_data()

            elif cmd == "STOP":
                self.stop()

            elif cmd == "SAMPLE":
                bit = self.sample_once()
                self.record_bit(bit, report=True)

            elif cmd == "RUN":
                self.run()

            elif cmd == "SET":
                if len(parts) < 3:
                    raise ValueError("SET requires name and value")
                key = parts[1].upper()

                if key == "MODE":
                    self.set_mode(parts[2])

                elif key == "TRIALS":
                    self.set_trials(parts[2])

                elif key == "REPORT_EVERY":
                    self.report_every = max(1, int(parts[2]))
                    print("EVENT,report_every_set,%d" % self.report_every)

                elif key == "FREQ":
                    self.freq_hz = max(1, int(float(parts[2])))
                    if self.is_internal_pwm_mode():
                        self.configure_pwm()
                    print("EVENT,freq_set,%d" % self.freq_hz)

                elif key == "DUTY":
                    self.duty_percent = max(0.0, min(100.0, float(parts[2])))
                    if self.is_internal_pwm_mode():
                        self.configure_pwm()
                    print("EVENT,duty_set,%.3f" % self.duty_percent)

                elif key == "RANDOM_US":
                    if len(parts) < 4:
                        raise ValueError("SET RANDOM_US requires min max")
                    a = int(parts[2])
                    b = int(parts[3])
                    if a < 0 or b < a:
                        raise ValueError("bad random range")
                    self.random_min_us = a
                    self.random_max_us = b
                    print("EVENT,random_us_set,%d,%d" % (a, b))

                elif key == "EXPECTED":
                    if parts[2].upper() == "AUTO":
                        self.expected = None
                    else:
                        self.expected = max(0.0, min(1.0, float(parts[2])))
                    print("EVENT,expected_set,%s" %
                          ("AUTO" if self.expected is None else ("%.6f" % self.expected)))

                elif key == "SAMPLE_LED_HOLD_MS":
                    self.sample_led_hold_ms = max(0, min(5, int(parts[2])))
                    print("EVENT,sample_led_hold_ms_set,%d" % self.sample_led_hold_ms)

                else:
                    raise ValueError("unknown SET key")

            elif cmd == "LED":
                if len(parts) < 2:
                    raise ValueError("LED requires state name")
                state = parts[1].lower()
                self.led.set(state)
                print("EVENT,led_set,%s" % state)

            else:
                print("ERROR,unknown_command,%s" % cmd)
                self.led.flash_blocking("error", 80, "ready" if not self.running else "running")

        except Exception as e:
            print("ERROR,%s,%s" % (cmd, repr(e)))
            self.led.flash_blocking("error", 100, "ready" if not self.running else "running")

    def poll_serial_once(self):
        if self.poller is None:
            return

        try:
            # Nonblocking char-buffer approach. Avoid readline(), which can block
            # after poll() if a newline has not arrived yet.
            count = 0
            while count < 64 and self.poller.poll(0):
                ch = sys.stdin.read(1)
                if not ch:
                    break

                if ch == "\n" or ch == "\r":
                    if self.rx_buffer:
                        line = self.rx_buffer
                        self.rx_buffer = ""
                        self.parse_command(line)
                else:
                    if len(self.rx_buffer) < 160:
                        self.rx_buffer += ch
                    else:
                        print("ERROR,rx_line_too_long")
                        self.rx_buffer = ""

                count += 1

        except Exception as e:
            print("WARN,serial_poll_error,%s" % repr(e))

    def repl_loop(self):
        self.led.set("ready")
        print("EVENT,ready")
        print("HELP,commands=HELLO STATUS CONFIG? BUTTON? CSV? SET MODE ... SET TRIALS n SET REPORT_EVERY n SET FREQ hz SET DUTY pct SET RANDOM_US min max SET EXPECTED AUTO|fraction SET SAMPLE_LED_HOLD_MS 0..5 RUN SAMPLE STOP RESET LED state")

        while True:
            self.poll_serial_once()

            # Outside RUN, button mode can still take one visible sample.
            if self.is_button_mode() and self.button_pressed():
                self.led.set("button")
                time.sleep_ms(20)  # debounce
                if self.button_pressed():
                    bit = self.sample_once()
                    self.record_bit(bit, report=True)
                    self.wait_button_release()
                    self.led.set("ready")

            time.sleep_ms(10)


# -----------------------------
# Startup
# -----------------------------

try:
    wb = Workbench()
    wb.repl_loop()
except Exception as e:
    try:
        led = StatusLED()
        led.set("error")
    except Exception:
        pass
    print("FATAL,%s" % repr(e))
    raise
